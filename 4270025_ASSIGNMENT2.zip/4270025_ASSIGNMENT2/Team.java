// Part A
// Student Number: 4270025
// Student Name: Makhanani Mlambo
// Assignment 2

public class Team implements Comparable<Team> {
    private String teamName;
    private int teamNumber, firstScore, secondScore;
    private long regYear;
    private double finalScore;

    public String getTeamName() {
        return teamName;
    }

    public int getTeamNumber() {
        return teamNumber;
    }

    public int getFirstScore() {
        return firstScore;
    }

    public int getSecondScore() {
        return secondScore;
    }

    public long getRegYear() {
        return regYear;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public void setTeamNumber(int teamNumber) {
        this.teamNumber = teamNumber;
    }

    public void setFirstScore(int firstScore) {
        this.firstScore = firstScore;
    }

    public void setSecondScore(int secondScore) {
        this.secondScore = secondScore;
    }

    public void setRegYear(long regYear) {
        this.regYear = regYear;
    }

    public double getFinalScore() {
        return finalScore;
    }

    public void setFinalScore(double finalScore) {
        this.finalScore = finalScore;
    }

    public Team(String teamName, int teamNumber, long regYear, int firstScore, int secondScore) {
        this.teamName = teamName;
        this.teamNumber = teamNumber;
        this.regYear = regYear;
        this.firstScore = firstScore;
        this.secondScore = secondScore;
        this.finalScore = calculateFinalScore();
    }

    private double calculateFinalScore() {
        return (this.firstScore + this.secondScore) / 2.0;
    }

    @Override
    public int compareTo(Team otherTeam) {
        if (this.finalScore != otherTeam.finalScore) {
            return Double.compare(otherTeam.finalScore, this.finalScore);
        } else if (!this.teamName.equals(otherTeam.teamName)) {
            return this.teamName.compareTo(otherTeam.teamName);
        } else {
            return Integer.compare(this.teamNumber, otherTeam.teamNumber);
        }
    }
}