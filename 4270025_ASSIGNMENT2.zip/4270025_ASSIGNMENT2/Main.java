// Student Name: Makhanani Mlambo
// Student Number: 4270025
// Assignment 2

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CompetitionEntry competitionEntry = new CompetitionEntry(null);

        CompetitionEntry.registerTeams(competitionEntry, scanner);

        System.out.println("Teams :");
        competitionEntry.display();
        System.out.println();

        System.out.println(
                "Please enter the sorting attribute you wish to use to sort the teams (teamName, teamNumber, regYear, firstScore, secondScore, finalScore):");
        String sortBy = scanner.nextLine();

        competitionEntry.sortTeams(sortBy);

        System.out.println("The teams are now sorted. BYE :>) :");
        competitionEntry.display();
    }
}