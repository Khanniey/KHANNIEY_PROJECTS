// Student Number: 4270025
// Student Name : Makhanani Mlambo
// Assignment 2

public class Node {
    private Team team;
    private Node nextNode;

    public Team getTeam() {
        return team;
    }

    public Node getNextNode() {
        return nextNode;
    }

    public void setTeam(Team team) {
        this.team = team;
    }

    public void setNextNode(Node nextNode) {
        this.nextNode = nextNode;
    }

    public Node(Team team) {
        this.team = team;
    }

    public Node(Node nextNode) {
        this.nextNode = null;
    }
}