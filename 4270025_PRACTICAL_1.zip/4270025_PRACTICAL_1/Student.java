public class Student {
    private String studentName;
    private int studentNumber;
    private long regYear;
    private String faculty;
    private String departm;
    private String gender;
    private String race;

    public Student(String studentName, int studentNumber, long regYear, String faculty, String departm, String gender,
            String race) {
        this.studentName = studentName;
        this.studentNumber = studentNumber;
        this.regYear = regYear;
        this.faculty = faculty;
        this.departm = departm;
        this.gender = gender;
        this.race = race;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public int getStudentNumber() {
        return studentNumber;
    }

    public void setStudentNumber(int studentNumber) {
        this.studentNumber = studentNumber;
    }

    public long getRegYear() {
        return regYear;
    }

    public void setRegYear(long regYear) {
        this.regYear = regYear;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public String getDepartm() {
        return departm;
    }

    public void setDepartm(String departm) {
        this.departm = departm;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }

    @Override
    public String toString() {
        return "Student{" +
                "studentName='" + studentName + '\'' +
                ", studentNumber=" + studentNumber +
                ", departm='" + departm + '\'' +
                '}';
    }
}
