//NAME : MAKHANANI MLAMBO
//STUDENT NUMBER : 4270025
//FILE NAME : LongestWord.java
//PRACTICAL 1

import java.io.*;
import java.io.FileReader;

public class LongestWord {
    private static String positionOfLongestWord;

    public static void main(String[] args) {
        try {

            BufferedReader inputFileReader = new BufferedReader(new FileReader("Words.txt"));

            BufferedWriter outputFileWriter = new BufferedWriter(new FileWriter("Words2.txt"));

            String punctuation = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~";
            String line;
            int position = 1;
            String longestWord = "";
            int longestLength = 0;

            while ((line = inputFileReader.readLine()) != null) {

                String[] words = line.split("\\s+");
                for (String word : words) {

                    StringBuilder cleanedWord = new StringBuilder();
                    for (int i = 0; i < word.length(); i++) {
                        char c = word.charAt(i);
                        if (punctuation.indexOf(c) == -1) {
                            cleanedWord.append(c);
                        }
                    }

                    outputFileWriter.write(position + " " + cleanedWord.toString() + "\n");

                    if (cleanedWord.length() > longestLength) {
                        longestLength = cleanedWord.length();
                        longestWord = cleanedWord.toString();
                        positionOfLongestWord = String.valueOf(position);
                    }

                    position++;
                }
            }

            inputFileReader.close();
            outputFileWriter.close();

            System.out.println("The longest word in this text file is [" + positionOfLongestWord + "]\n" + longestWord
                    + " with " + longestLength + " letters.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
