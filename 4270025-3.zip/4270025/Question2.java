import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class Question2 {

    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("anagrams.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] words = line.split(",");
                String str1 = words[0].trim();
                String str2 = words[1].trim();

                boolean result = areAnagrams(str1, str2);
                System.out.println(result);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * @param str1
     * @param str2
     * @return
     */
    public static boolean areAnagrams(String str1, String str2) {
        StringBuilder sb1 = new StringBuilder();
        for (char c : str1.toCharArray()) {
            if (c != ' ') {
                sb1.append(Character.toLowerCase(c));

                if (str1.length() != str2.length()) {
                    return false;
                }

                char[] charArray1 = str1.toCharArray();
                char[] charArray2 = str2.toCharArray();
                Arrays.sort(charArray1);
                Arrays.sort(charArray2);

                return Arrays.equals(charArray1, charArray2);
            }
        }
        return false;
    }
}
