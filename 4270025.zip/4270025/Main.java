import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        PriorityQueue heap = new PriorityQueue(25);
        String fileName = "flights.txt";

        try (BufferedReader br = new BufferedReader(new InputStreamReader(Main.class.getResourceAsStream(fileName)))) {
            boolean headerSkipped = false;
            String line;
            while ((line = br.readLine()) != null) {
                if (!headerSkipped) {
                    headerSkipped = true;
                    continue;
                }

                String[] flightData = line.split(",");
                String registrationNo = flightData[0].trim();
                String departureTimeStr = flightData[1].trim();
                String durationStr = flightData[2].trim();

                Date departureTime = parseTime(departureTimeStr);
                Date arrivalTime = calculateArrivalTime(departureTime, durationStr);

                Node flightNode = new Node(registrationNo, arrivalTime);
                heap.add(flightNode);
            }

            System.out.println("Order of incoming flights:");
            while (!heap.isEmpty()) {
                Node nextFlight = heap.remove();
                System.out.println(nextFlight.getFlight_no() + ": " + nextFlight.getArrival_time());
            }
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
    }

    private static Date parseTime(String timeStr) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        return sdf.parse(timeStr);
    }

    private static Date calculateArrivalTime(Date departureTime, String durationStr) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        Date duration = sdf.parse(durationStr);

        long arrivalTimeMillis = departureTime.getTime() + duration.getTime();
        return new Date(arrivalTimeMillis);
    }
}